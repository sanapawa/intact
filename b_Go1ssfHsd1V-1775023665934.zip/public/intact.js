// INTACT Health Insurance AI - JavaScript

// State
let currentStep = 1;
const totalSteps = 4;

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
  // Hide splash screen after animation
  setTimeout(() => {
    const splash = document.getElementById('splash-screen');
    splash.classList.add('hidden');
  }, 3200);

  // Setup chat input enter key
  const chatInput = document.getElementById('chat-input');
  if (chatInput) {
    chatInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        sendUserMessage();
      }
    });
  }
});

// Navigation
function navigateTo(screenId) {
  // Hide all screens
  document.querySelectorAll('.screen').forEach(screen => {
    screen.classList.remove('active');
  });

  // Show target screen
  const targetScreen = document.getElementById('screen-' + screenId);
  if (targetScreen) {
    targetScreen.classList.add('active');
  }

  // Update nav items
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active');
    if (item.dataset.screen === screenId) {
      item.classList.add('active');
    }
  });

  // Reset claim flow when navigating to it
  if (screenId === 'claim-flow') {
    resetClaimFlow();
  }
}

// Chat functionality
function sendMessage(text) {
  addUserMessage(text);
  
  // Simulate AI response
  setTimeout(() => {
    let response = getAIResponse(text);
    addAIMessage(response);
  }, 1000);
}

function sendUserMessage() {
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  
  if (text) {
    addUserMessage(text);
    input.value = '';
    
    // Simulate AI response
    setTimeout(() => {
      let response = getAIResponse(text);
      addAIMessage(response);
    }, 1000);
  }
}

function addUserMessage(text) {
  const messagesContainer = document.getElementById('chat-messages');
  const messageDiv = document.createElement('div');
  messageDiv.className = 'message user';
  messageDiv.innerHTML = `<div class="message-bubble">${text}</div>`;
  messagesContainer.appendChild(messageDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function addAIMessage(text) {
  const messagesContainer = document.getElementById('chat-messages');
  const messageDiv = document.createElement('div');
  messageDiv.className = 'message ai';
  messageDiv.innerHTML = `<div class="message-bubble">${text}</div>`;
  messagesContainer.appendChild(messageDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function getAIResponse(query) {
  const lowerQuery = query.toLowerCase();
  
  if (lowerQuery.includes('surgery') || lowerQuery.includes('covered')) {
    return "Yes, your policy covers most surgeries up to &#8377;5,00,000. For knee surgery specifically, you're covered for up to &#8377;50,000. You may need to pay approximately &#8377;5,000 extra if your room rent exceeds the &#8377;3,000/day limit.";
  } else if (lowerQuery.includes('document') || lowerQuery.includes('need')) {
    return "For a cashless claim, you'll need: 1) Hospital admission papers, 2) Doctor's prescription, 3) ID proof, and 4) Health card. I can help you scan and upload these documents.";
  } else if (lowerQuery.includes('room') || lowerQuery.includes('rent') || lowerQuery.includes('limit')) {
    return "Your room rent limit is &#8377;3,000/day. If you choose a room costing &#8377;4,000/day, you'll need to pay the extra &#8377;1,000/day yourself. I recommend choosing a room within your limit to avoid extra costs.";
  } else if (lowerQuery.includes('claim') || lowerQuery.includes('status')) {
    return "Your recent claim (CLM-2024-1847) is currently under review. It was submitted on March 15 and is expected to be approved within 2-3 business days. I'll notify you as soon as there's an update.";
  } else if (lowerQuery.includes('hospital') || lowerQuery.includes('cashless')) {
    return "You have access to 8,000+ cashless hospitals across India. Some popular ones near you include Apollo Hospitals, Max Healthcare, and Fortis. Would you like me to help you find the nearest one?";
  } else {
    return "I understand you have a question about your health insurance. Could you please provide more details? I can help you with coverage queries, claim status, document requirements, or finding cashless hospitals.";
  }
}

// Claim Flow
function nextStep() {
  if (currentStep < totalSteps) {
    // Hide current step
    document.getElementById('flow-step-' + currentStep).classList.remove('active');
    
    // Show next step
    currentStep++;
    document.getElementById('flow-step-' + currentStep).classList.add('active');
    
    // Update UI
    updateFlowUI();
  } else {
    // Submit complete - go to status
    setTimeout(() => {
      navigateTo('claim-status');
    }, 2000);
  }
}

function previousStep() {
  if (currentStep > 1) {
    // Hide current step
    document.getElementById('flow-step-' + currentStep).classList.remove('active');
    
    // Show previous step
    currentStep--;
    document.getElementById('flow-step-' + currentStep).classList.add('active');
    
    // Update UI
    updateFlowUI();
  }
}

function updateFlowUI() {
  // Update step indicator
  document.getElementById('current-step').textContent = currentStep;
  
  // Update progress bar
  const progress = (currentStep / totalSteps) * 100;
  document.getElementById('flow-progress-bar').style.width = progress + '%';
  
  // Update buttons
  const backBtn = document.getElementById('flow-back-btn');
  const nextBtn = document.getElementById('flow-next-btn');
  
  backBtn.style.display = currentStep > 1 ? 'block' : 'none';
  
  if (currentStep === totalSteps) {
    nextBtn.textContent = 'Track Claim';
  } else {
    nextBtn.textContent = 'Continue';
  }
}

function resetClaimFlow() {
  currentStep = 1;
  
  // Hide all steps
  document.querySelectorAll('.flow-step').forEach(step => {
    step.classList.remove('active');
  });
  
  // Show first step
  document.getElementById('flow-step-1').classList.add('active');
  
  // Reset UI
  updateFlowUI();
  
  // Reset hospital selection
  document.querySelectorAll('.hospital-item').forEach(item => {
    item.classList.remove('selected');
  });
}

function selectHospital(element) {
  // Remove selection from all
  document.querySelectorAll('.hospital-item').forEach(item => {
    item.classList.remove('selected');
  });
  
  // Add selection to clicked
  element.classList.add('selected');
}

// Document Scanner
function simulateScan() {
  const statusText = document.querySelector('.scanner-status span:last-child');
  const statusDot = document.querySelector('.status-dot');
  
  // Scanning state
  statusText.textContent = 'Scanning...';
  statusDot.style.background = '#F59E0B';
  
  setTimeout(() => {
    statusText.textContent = 'Document captured!';
    statusDot.style.background = '#22C55E';
    
    // Add scanned document
    addScannedDoc();
    
    // Reset after delay
    setTimeout(() => {
      statusText.textContent = 'Ready to scan';
    }, 2000);
  }, 1500);
}

function addScannedDoc() {
  const scannedList = document.getElementById('scanned-list');
  
  // Remove empty state if present
  const emptyState = scannedList.querySelector('.empty-state');
  if (emptyState) {
    emptyState.remove();
  }
  
  // Add scanned item
  const docTypes = ['Bill', 'Report', 'Prescription', 'ID'];
  const docType = docTypes[scannedList.children.length % docTypes.length];
  
  const item = document.createElement('div');
  item.className = 'scanned-item';
  item.innerHTML = `
    <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/>
    </svg>
    <span>${docType}</span>
  `;
  
  scannedList.appendChild(item);
}

// Policy Explainer
function togglePolicy(element) {
  element.classList.toggle('expanded');
}
