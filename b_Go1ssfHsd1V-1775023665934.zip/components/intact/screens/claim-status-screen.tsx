"use client"

import { motion } from "framer-motion"
import { 
  ArrowLeft, 
  Check,
  Clock,
  FileText,
  Building2,
  CreditCard,
  Sparkles,
  ChevronRight,
  MessageCircle
} from "lucide-react"

const claimTimeline = [
  {
    id: 1,
    title: "Request Submitted",
    description: "Your claim has been received and logged",
    time: "Today, 10:30 AM",
    status: "complete",
    aiNote: "Your documents look good! No issues detected.",
    icon: FileText,
  },
  {
    id: 2,
    title: "Under Review",
    description: "Claim is being reviewed by the insurer",
    time: "In Progress",
    status: "current",
    aiNote: "Currently with the insurer. Usually takes 2-3 days.",
    icon: Clock,
  },
  {
    id: 3,
    title: "Approved",
    description: "Your claim has been approved",
    time: "Pending",
    status: "pending",
    aiNote: null,
    icon: Check,
  },
  {
    id: 4,
    title: "Payment Released",
    description: "Amount credited to hospital/your account",
    time: "Pending",
    status: "pending",
    aiNote: null,
    icon: CreditCard,
  },
]

interface ClaimStatusScreenProps {
  onBack: () => void
  onNavigate: (screen: string) => void
}

export function ClaimStatusScreen({ onBack, onNavigate }: ClaimStatusScreenProps) {
  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="px-5 py-4 border-b border-border/50 flex items-center gap-4">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-card flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </motion.button>
        <div>
          <h1 className="text-lg font-semibold text-foreground">Claim Status</h1>
          <p className="text-xs text-muted-foreground">CLM-2024-001</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-6 space-y-6">
        {/* Claim Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 rounded-2xl bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-4">
              <Building2 className="w-5 h-5 text-white/90" />
              <span className="text-white/90 text-sm font-medium">Apollo Hospital</span>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-white/70 text-xs uppercase tracking-wider mb-1">Claim Amount</p>
                <p className="text-2xl font-bold text-white">₹45,000</p>
              </div>
              <div>
                <p className="text-white/70 text-xs uppercase tracking-wider mb-1">Status</p>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#F59E0B] rounded-full animate-pulse" />
                  <span className="text-white font-medium">In Review</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Timeline */}
        <div>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">Timeline</h2>
          
          <div className="space-y-0">
            {claimTimeline.map((step, index) => (
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative flex gap-4"
              >
                {/* Timeline Line */}
                {index < claimTimeline.length - 1 && (
                  <div className="absolute left-5 top-10 bottom-0 w-0.5 bg-border">
                    {step.status === "complete" && (
                      <motion.div
                        className="w-full bg-[#22C55E]"
                        initial={{ height: 0 }}
                        animate={{ height: "100%" }}
                        transition={{ duration: 0.5, delay: index * 0.2 }}
                      />
                    )}
                  </div>
                )}

                {/* Icon */}
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", delay: index * 0.1 }}
                  className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                    step.status === "complete"
                      ? "bg-[#22C55E]"
                      : step.status === "current"
                        ? "bg-primary"
                        : "bg-muted"
                  }`}
                >
                  <step.icon className={`w-5 h-5 ${
                    step.status === "pending" ? "text-muted-foreground" : "text-white"
                  }`} />
                </motion.div>

                {/* Content */}
                <div className="flex-1 pb-6">
                  <div className="flex items-start justify-between mb-1">
                    <h3 className={`font-semibold ${
                      step.status === "pending" ? "text-muted-foreground" : "text-foreground"
                    }`}>
                      {step.title}
                    </h3>
                    <span className={`text-xs ${
                      step.status === "pending" ? "text-muted-foreground" : "text-muted-foreground"
                    }`}>
                      {step.time}
                    </span>
                  </div>
                  
                  <p className={`text-sm mb-3 ${
                    step.status === "pending" ? "text-muted-foreground/60" : "text-muted-foreground"
                  }`}>
                    {step.description}
                  </p>

                  {/* AI Note */}
                  {step.aiNote && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.2 + 0.3 }}
                      className="p-3 rounded-xl bg-card border border-border/50"
                    >
                      <div className="flex items-start gap-2">
                        <Sparkles className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <p className="text-xs text-foreground">{step.aiNote}</p>
                      </div>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Help Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          onClick={() => onNavigate("ai-chat")}
          className="p-4 rounded-2xl bg-card border border-border/50 cursor-pointer hover:border-primary/30 transition-colors"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="font-medium text-foreground text-sm">Need Help?</p>
                <p className="text-xs text-muted-foreground">Chat with INTACT AI</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </div>
        </motion.div>
      </div>
    </div>
  )
}
