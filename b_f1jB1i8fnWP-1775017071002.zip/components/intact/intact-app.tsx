"use client"

import { useState } from "react"
import { AnimatePresence, motion } from "framer-motion"
import { PhoneFrame } from "./phone-frame"
import { BottomNavigation } from "./bottom-navigation"
import { HomeScreen } from "./screens/home-screen"
import { AIChatScreen } from "./screens/ai-chat-screen"
import { ClaimFlowScreen } from "./screens/claim-flow-screen"
import { DocumentScannerScreen } from "./screens/document-scanner-screen"
import { ClaimStatusScreen } from "./screens/claim-status-screen"
import { PolicyExplainerScreen } from "./screens/policy-explainer-screen"

type Screen = 
  | "home" 
  | "ai-chat" 
  | "claim-flow" 
  | "document-scanner" 
  | "claim-status" 
  | "policy"
  | "profile"

const screensWithNav = ["home", "claim-status", "ai-chat", "profile"]

export function IntactApp() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("home")
  const [screenHistory, setScreenHistory] = useState<Screen[]>(["home"])

  const navigateTo = (screen: string) => {
    const typedScreen = screen as Screen
    setScreenHistory((prev) => [...prev, typedScreen])
    setCurrentScreen(typedScreen)
  }

  const goBack = () => {
    if (screenHistory.length > 1) {
      const newHistory = screenHistory.slice(0, -1)
      setScreenHistory(newHistory)
      setCurrentScreen(newHistory[newHistory.length - 1])
    }
  }

  const showNav = screensWithNav.includes(currentScreen)

  return (
    <PhoneFrame>
      <div className="relative h-full">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentScreen}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
            className={`h-full ${showNav ? "pb-20" : ""}`}
          >
            {currentScreen === "home" && (
              <HomeScreen onNavigate={navigateTo} />
            )}
            {currentScreen === "ai-chat" && (
              <AIChatScreen onBack={goBack} />
            )}
            {currentScreen === "claim-flow" && (
              <ClaimFlowScreen onBack={goBack} onNavigate={navigateTo} />
            )}
            {currentScreen === "document-scanner" && (
              <DocumentScannerScreen onBack={goBack} />
            )}
            {currentScreen === "claim-status" && (
              <ClaimStatusScreen onBack={goBack} onNavigate={navigateTo} />
            )}
            {currentScreen === "policy" && (
              <PolicyExplainerScreen onBack={goBack} onNavigate={navigateTo} />
            )}
            {currentScreen === "profile" && (
              <ProfileScreen onBack={goBack} />
            )}
          </motion.div>
        </AnimatePresence>

        {showNav && (
          <BottomNavigation 
            activeScreen={currentScreen} 
            onNavigate={navigateTo}
          />
        )}
      </div>
    </PhoneFrame>
  )
}

// Simple Profile Screen
function ProfileScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex flex-col h-full bg-background px-5 py-6">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] flex items-center justify-center">
          <span className="text-white text-2xl font-bold">S</span>
        </div>
        <div>
          <h1 className="text-xl font-bold text-foreground">Sana Sharma</h1>
          <p className="text-sm text-muted-foreground">sana.sharma@email.com</p>
        </div>
      </div>

      <div className="space-y-3">
        {[
          { label: "My Policies", icon: "📋" },
          { label: "Family Members", icon: "👨‍👩‍👧‍👦" },
          { label: "Payment History", icon: "💳" },
          { label: "Download Card", icon: "📥" },
          { label: "Help & Support", icon: "❓" },
          { label: "Settings", icon: "⚙️" },
        ].map((item) => (
          <button
            key={item.label}
            className="w-full p-4 rounded-2xl bg-card border border-border/50 flex items-center justify-between hover:border-primary/30 transition-colors"
          >
            <div className="flex items-center gap-3">
              <span className="text-lg">{item.icon}</span>
              <span className="font-medium text-foreground">{item.label}</span>
            </div>
            <svg className="w-5 h-5 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        ))}
      </div>

      <button className="mt-auto py-4 text-center text-[#DC2626] font-medium">
        Sign Out
      </button>
    </div>
  )
}
