"use client"

import dynamic from "next/dynamic"

const IntactPage = dynamic(
  () => import("@/components/intact/intact-page").then((mod) => mod.IntactPage),
  { ssr: false }
)

export default function Page() {
  return <IntactPage />
}
