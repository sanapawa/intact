"use client"

import { motion } from "framer-motion"
import { Home, FileText, MessageCircle, User } from "lucide-react"

const navItems = [
  { id: "home", icon: Home, label: "Home" },
  { id: "claim-status", icon: FileText, label: "Claims" },
  { id: "ai-chat", icon: MessageCircle, label: "AI Chat" },
  { id: "profile", icon: User, label: "Profile" },
]

interface BottomNavigationProps {
  activeScreen: string
  onNavigate: (screen: string) => void
}

export function BottomNavigation({ activeScreen, onNavigate }: BottomNavigationProps) {
  const getActiveTab = () => {
    if (activeScreen === "home") return "home"
    if (activeScreen === "claim-status" || activeScreen === "claim-flow") return "claim-status"
    if (activeScreen === "ai-chat") return "ai-chat"
    return "home"
  }

  const activeTab = getActiveTab()

  return (
    <div className="px-4 pb-2 pt-1 bg-background border-t border-border/30">
      <div className="flex items-center justify-around bg-card/80 backdrop-blur-xl rounded-2xl py-2 border border-border/30">
        {navItems.map((item) => (
          <motion.button
            key={item.id}
            whileTap={{ scale: 0.9 }}
            onClick={() => onNavigate(item.id)}
            className={`flex flex-col items-center gap-1 px-4 py-2 rounded-xl transition-colors ${
              activeTab === item.id ? "text-primary" : "text-muted-foreground"
            }`}
          >
            <motion.div
              animate={{
                scale: activeTab === item.id ? 1.1 : 1,
              }}
            >
              <item.icon className="w-5 h-5" />
            </motion.div>
            <span className="text-[10px] font-medium">{item.label}</span>
            {activeTab === item.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute bottom-0 w-1 h-1 bg-primary rounded-full"
              />
            )}
          </motion.button>
        ))}
      </div>
    </div>
  )
}
