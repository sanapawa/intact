"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { 
  ArrowLeft, 
  X,
  Zap,
  Check,
  AlertTriangle,
  FileText,
  Camera,
  RotateCcw,
  Sparkles
} from "lucide-react"

interface ScannedDoc {
  id: string
  name: string
  status: "clear" | "warning" | "scanning"
  message: string
  preview: string
}

const documentTypes = [
  { id: "bill", name: "Hospital Bill", icon: "📄" },
  { id: "discharge", name: "Discharge Summary", icon: "📋" },
  { id: "reports", name: "Lab Reports", icon: "🔬" },
  { id: "prescription", name: "Prescription", icon: "💊" },
]

interface DocumentScannerScreenProps {
  onBack: () => void
}

export function DocumentScannerScreen({ onBack }: DocumentScannerScreenProps) {
  const [isScanning, setIsScanning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [scannedDocs, setScannedDocs] = useState<ScannedDoc[]>([])
  const [showCamera, setShowCamera] = useState(true)

  useEffect(() => {
    if (isScanning) {
      const interval = setInterval(() => {
        setScanProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval)
            setIsScanning(false)
            
            // Add scanned document
            const newDoc: ScannedDoc = {
              id: Date.now().toString(),
              name: documentTypes[Math.floor(Math.random() * documentTypes.length)].name,
              status: Math.random() > 0.3 ? "clear" : "warning",
              message: Math.random() > 0.3 
                ? "Document is clear and readable" 
                : "Signature appears to be missing",
              preview: `/placeholder.svg?height=120&width=80&query=medical document scan ${Date.now()}`,
            }
            setScannedDocs((prev) => [...prev, newDoc])
            return 0
          }
          return prev + 5
        })
      }, 50)
      return () => clearInterval(interval)
    }
  }, [isScanning])

  const handleCapture = () => {
    setIsScanning(true)
    setScanProgress(0)
  }

  const removeDoc = (id: string) => {
    setScannedDocs(scannedDocs.filter((d) => d.id !== id))
  }

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="px-5 py-4 border-b border-border/50 flex items-center gap-4">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-card flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </motion.button>
        <div>
          <h1 className="text-lg font-semibold text-foreground">Document Scanner</h1>
          <p className="text-xs text-muted-foreground">AI-powered document detection</p>
        </div>
      </div>

      {/* Camera View */}
      {showCamera && (
        <div className="relative flex-1 bg-[#1D4ED8]/8 overflow-hidden border-y border-border/50">
          {/* Camera Preview Simulation */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-[280px] h-[380px]">
              {/* Document Frame */}
              <motion.div
                animate={{
                  borderColor: isScanning ? "#1D4ED8" : "#6B7280",
                }}
                className="absolute inset-0 border-2 border-dashed rounded-2xl"
              >
                {/* Corner indicators */}
                <div className="absolute -top-1 -left-1 w-8 h-8 border-l-4 border-t-4 border-primary rounded-tl-xl" />
                <div className="absolute -top-1 -right-1 w-8 h-8 border-r-4 border-t-4 border-primary rounded-tr-xl" />
                <div className="absolute -bottom-1 -left-1 w-8 h-8 border-l-4 border-b-4 border-primary rounded-bl-xl" />
                <div className="absolute -bottom-1 -right-1 w-8 h-8 border-r-4 border-b-4 border-primary rounded-br-xl" />
              </motion.div>

              {/* Scanning Animation */}
              {isScanning && (
                <motion.div
                  className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent"
                  animate={{ top: ["0%", "100%"] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                />
              )}

              {/* Document Preview (simulated) */}
              <div className="absolute inset-4 bg-[#F3F4F6] rounded-xl flex items-center justify-center">
                <div className="text-center">
                  <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">Position document here</p>
                </div>
              </div>
            </div>
          </div>

          {/* AI Detection Status */}
          <div className="absolute top-4 left-4 right-4">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 backdrop-blur-sm w-fit border border-border/40 shadow-sm">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm text-foreground">
                {isScanning ? "Scanning document..." : "Auto-detect enabled"}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          {isScanning && (
            <div className="absolute bottom-32 left-8 right-8">
              <div className="h-1 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-primary"
                  style={{ width: `${scanProgress}%` }}
                />
              </div>
              <p className="text-center text-sm text-muted-foreground mt-2">
                Analyzing document... {scanProgress}%
              </p>
            </div>
          )}

          {/* Capture Button */}
          <div className="absolute bottom-8 left-0 right-0 flex items-center justify-center gap-6">
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="w-12 h-12 rounded-full bg-white border border-border/40 shadow-sm flex items-center justify-center"
            >
              <RotateCcw className="w-6 h-6 text-[#0B0B0B]" />
            </motion.button>
            
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={handleCapture}
              disabled={isScanning}
              className={`w-20 h-20 rounded-full flex items-center justify-center border-4 border-[#1D4ED8]/30 transition-all ${
                isScanning ? "bg-primary/50" : "bg-white shadow-lg"
              }`}
            >
              <div className={`w-14 h-14 rounded-full border-2 border-[#E5E7EB] flex items-center justify-center ${
                isScanning ? "bg-primary/40" : "bg-[#1D4ED8]"
              }`}>
                <Camera className={`w-7 h-7 ${isScanning ? "text-white/50" : "text-white"}`} />
              </div>
            </motion.button>
            
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => setShowCamera(false)}
              className="w-12 h-12 rounded-full bg-white border border-border/40 shadow-sm flex items-center justify-center"
            >
              <FileText className="w-6 h-6 text-[#0B0B0B]" />
            </motion.button>
          </div>
        </div>
      )}

      {/* Scanned Documents Preview */}
      {!showCamera && (
        <div className="flex-1 overflow-y-auto px-5 py-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-foreground">Scanned Documents</h2>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowCamera(true)}
              className="px-4 py-2 rounded-full bg-primary text-white text-sm font-medium flex items-center gap-2"
            >
              <Camera className="w-4 h-4" />
              Scan More
            </motion.button>
          </div>

          <AnimatePresence>
            {scannedDocs.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center py-12"
              >
                <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
                  <FileText className="w-8 h-8 text-muted-foreground" />
                </div>
                <p className="text-muted-foreground text-sm">No documents scanned yet</p>
                <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setShowCamera(true)}
                  className="mt-4 px-6 py-3 rounded-full bg-primary text-white font-medium"
                >
                  Start Scanning
                </motion.button>
              </motion.div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {scannedDocs.map((doc) => (
                  <motion.div
                    key={doc.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className="relative bg-card border border-border/50 rounded-2xl p-3 overflow-hidden"
                  >
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={() => removeDoc(doc.id)}
                      className="absolute top-2 right-2 w-6 h-6 rounded-full bg-[#0B0B0B]/10 border border-border/50 flex items-center justify-center z-10"
                    >
                      <X className="w-3 h-3 text-[#0B0B0B]" />
                    </motion.button>
                    
                    <div className="aspect-[3/4] bg-muted rounded-xl mb-3 flex items-center justify-center">
                      <FileText className="w-8 h-8 text-muted-foreground" />
                    </div>
                    
                    <p className="font-medium text-sm text-foreground mb-1 truncate">{doc.name}</p>
                    
                    <div className={`flex items-center gap-1.5 ${
                      doc.status === "clear" ? "text-[#22C55E]" : "text-[#F59E0B]"
                    }`}>
                      {doc.status === "clear" ? (
                        <Check className="w-3 h-3" />
                      ) : (
                        <AlertTriangle className="w-3 h-3" />
                      )}
                      <span className="text-[10px] font-medium">
                        {doc.status === "clear" ? "Clear" : "Warning"}
                      </span>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </AnimatePresence>

          {scannedDocs.length > 0 && (
            <div className="pt-4">
              <div className="p-4 rounded-2xl bg-card border border-border/50">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground mb-1">AI Analysis</p>
                    <p className="text-xs text-muted-foreground">
                      {scannedDocs.some(d => d.status === "warning")
                        ? "Some documents need attention. Please check the warnings."
                        : "All documents are clear and ready for submission."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Footer - Show when docs are scanned and not in camera mode */}
      {!showCamera && scannedDocs.length > 0 && (
        <div className="px-5 py-4 border-t border-border/50">
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={onBack}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#1D4ED8] to-[#1E40AF] text-white font-semibold"
          >
            Done ({scannedDocs.length} documents)
          </motion.button>
        </div>
      )}
    </div>
  )
}
