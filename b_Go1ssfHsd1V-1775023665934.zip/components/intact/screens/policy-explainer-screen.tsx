"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { 
  ArrowLeft, 
  ChevronDown,
  Bed,
  Stethoscope,
  Pill,
  Ambulance,
  Baby,
  Heart,
  Sparkles,
  HelpCircle
} from "lucide-react"

const policyItems = [
  {
    id: "room",
    icon: Bed,
    title: "Room Rent Limit",
    value: "₹3,000/day",
    explanation: "If your room costs ₹4,000/day, you pay ₹1,000/day extra. All medical expenses are also reduced proportionally.",
    tip: "Choose a room within this limit for zero co-pay",
    color: "from-[#1D4ED8] to-[#1E40AF]",
  },
  {
    id: "surgery",
    icon: Stethoscope,
    title: "Surgery Coverage",
    value: "Up to ₹2,00,000",
    explanation: "Major surgeries are covered up to this limit per surgery. Includes surgeon fees, anesthesia, and OT charges.",
    tip: "Pre-approval recommended for planned surgeries",
    color: "from-[#1D4ED8]/90 to-[#1E40AF]/90",
  },
  {
    id: "medicines",
    icon: Pill,
    title: "Medicine Coverage",
    value: "100% Covered",
    explanation: "All prescribed medicines during hospitalization are fully covered. Post-discharge medicines for up to 30 days included.",
    tip: "Keep all pharmacy bills for reimbursement",
    color: "from-[#1D4ED8]/80 to-[#1E40AF]/80",
  },
  {
    id: "ambulance",
    icon: Ambulance,
    title: "Ambulance",
    value: "₹3,000/trip",
    explanation: "Emergency ambulance charges covered up to ₹3,000 per trip. Includes both to and from hospital.",
    tip: "Use network ambulance services when possible",
    color: "from-[#1D4ED8]/70 to-[#1E40AF]/70",
  },
  {
    id: "maternity",
    icon: Baby,
    title: "Maternity Benefit",
    value: "₹50,000",
    explanation: "Covers normal delivery up to ₹35,000 and C-section up to ₹50,000. Available after 2 years waiting period.",
    tip: "Waiting period: 24 months from policy start",
    color: "from-[#1D4ED8]/60 to-[#1E40AF]/60",
  },
  {
    id: "preexisting",
    icon: Heart,
    title: "Pre-existing Conditions",
    value: "After 2 Years",
    explanation: "Conditions like diabetes, hypertension are covered after 24 months waiting period. Declare all conditions at enrollment.",
    tip: "Your waiting period ends January 2025",
    color: "from-[#1D4ED8]/50 to-[#1E40AF]/50",
  },
]

interface PolicyExplainerScreenProps {
  onBack: () => void
  onNavigate: (screen: string) => void
}

export function PolicyExplainerScreen({ onBack, onNavigate }: PolicyExplainerScreenProps) {
  const [expandedItem, setExpandedItem] = useState<string | null>(null)

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="px-5 py-4 border-b border-border/50 flex items-center gap-4">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-card flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </motion.button>
        <div>
          <h1 className="text-lg font-semibold text-foreground">Your Policy</h1>
          <p className="text-xs text-muted-foreground">Family Floater Plan</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-6 space-y-4">
        {/* Policy Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 rounded-2xl bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-20 h-20 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
          
          <div className="relative z-10">
            <p className="text-white/70 text-xs uppercase tracking-wider mb-1">Total Coverage</p>
            <p className="text-3xl font-bold text-white mb-4">₹5,00,000</p>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-white/70 text-xs">Policy Number</p>
                <p className="text-white font-medium text-sm">INT-2024-001234</p>
              </div>
              <div>
                <p className="text-white/70 text-xs">Valid Till</p>
                <p className="text-white font-medium text-sm">Jan 15, 2025</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* AI Explanation Note */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex items-start gap-3 p-4 rounded-2xl bg-primary/10 border border-primary/20"
        >
          <Sparkles className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
          <p className="text-sm text-foreground">
            Tap any benefit below to see a simple explanation of what it means for you.
          </p>
        </motion.div>

        {/* Policy Benefits */}
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
            What&apos;s Covered
          </h2>
          
          {policyItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.05 }}
            >
              <motion.button
                whileTap={{ scale: 0.98 }}
                onClick={() => setExpandedItem(expandedItem === item.id ? null : item.id)}
                className="w-full p-4 rounded-2xl bg-card border border-border/50 text-left"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center`}>
                      <item.icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{item.title}</p>
                      <p className="text-sm text-primary font-semibold">{item.value}</p>
                    </div>
                  </div>
                  <motion.div
                    animate={{ rotate: expandedItem === item.id ? 180 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <ChevronDown className="w-5 h-5 text-muted-foreground" />
                  </motion.div>
                </div>

                <AnimatePresence>
                  {expandedItem === item.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="pt-4 mt-4 border-t border-border/50 space-y-3">
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {item.explanation}
                        </p>
                        
                        <div className="flex items-start gap-2 p-3 rounded-xl bg-[#22C55E]/10 border border-[#22C55E]/20">
                          <HelpCircle className="w-4 h-4 text-[#22C55E] flex-shrink-0 mt-0.5" />
                          <p className="text-xs text-[#22C55E]">{item.tip}</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.button>
            </motion.div>
          ))}
        </div>

        {/* Ask AI Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          onClick={() => onNavigate("ai-chat")}
          className="p-4 rounded-2xl bg-card border border-border/50 cursor-pointer hover:border-primary/30 transition-colors"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-medium text-foreground text-sm">Still confused?</p>
                <p className="text-xs text-muted-foreground">Ask INTACT AI anything</p>
              </div>
            </div>
            <div className="px-3 py-1.5 rounded-full bg-primary/20 text-primary text-xs font-medium">
              Ask AI
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
