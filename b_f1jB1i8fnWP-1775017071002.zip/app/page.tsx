"use client"

import { IntactApp } from "@/components/intact/intact-app"

export default function Page() {
  return (
    <main className="min-h-screen bg-[#0B0B0B] flex items-center justify-center p-4 md:p-8">
      {/* Background gradient */}
      <div className="fixed inset-0 bg-gradient-to-br from-[#1D4ED8]/5 via-transparent to-[#1D4ED8]/5 pointer-events-none" />
      
      {/* App Header */}
      <div className="fixed top-0 left-0 right-0 flex items-center justify-between px-6 py-4 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
            </svg>
          </div>
          <span className="text-white font-bold text-lg tracking-tight">INTACT</span>
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
          <span>Health Insurance AI App</span>
          <span className="text-primary font-medium">Interactive Demo</span>
        </div>
      </div>

      {/* Phone Container */}
      <div className="relative z-10 mt-16">
        <IntactApp />
      </div>

      {/* Feature highlights - Desktop only */}
      <div className="hidden lg:block fixed left-8 top-1/2 -translate-y-1/2 max-w-[200px] space-y-4">
        <FeatureCard 
          title="AI-Powered" 
          description="Get instant answers about your coverage"
        />
        <FeatureCard 
          title="Smart Scanner" 
          description="Auto-detect and validate documents"
        />
        <FeatureCard 
          title="Real-time Tracking" 
          description="Monitor your claim status live"
        />
      </div>

      <div className="hidden lg:block fixed right-8 top-1/2 -translate-y-1/2 max-w-[200px] space-y-4">
        <FeatureCard 
          title="Policy Explainer" 
          description="Understand your coverage in plain language"
        />
        <FeatureCard 
          title="Cashless Claims" 
          description="File claims at 8,000+ hospitals"
        />
        <FeatureCard 
          title="Always There" 
          description="A calm companion when you need it"
        />
      </div>
    </main>
  )
}

function FeatureCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="p-4 rounded-2xl bg-card/50 border border-border/30 backdrop-blur-sm">
      <h3 className="text-foreground font-semibold text-sm mb-1">{title}</h3>
      <p className="text-muted-foreground text-xs">{description}</p>
    </div>
  )
}
