"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { 
  ArrowLeft, 
  Mic, 
  Paperclip, 
  Send, 
  Sparkles,
  ChevronRight
} from "lucide-react"

interface Message {
  id: string
  type: "user" | "ai"
  content: string
  timestamp: Date
}

const suggestedPrompts = [
  "Am I covered for knee surgery?",
  "How do I file a cashless claim?",
  "What&apos;s my room rent limit?",
  "Pre-existing conditions coverage?",
]

const initialMessages: Message[] = [
  {
    id: "1",
    type: "ai",
    content: "Hi Sana! I'm here to help you understand your health insurance. What would you like to know?",
    timestamp: new Date(),
  },
]

interface AIChatScreenProps {
  onBack: () => void
}

export function AIChatScreen({ onBack }: AIChatScreenProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = async (text?: string) => {
    const messageText = text || inputValue
    if (!messageText.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: messageText,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate AI response
    setTimeout(() => {
      let aiResponse = ""
      
      if (messageText.toLowerCase().includes("knee") || messageText.toLowerCase().includes("surgery")) {
        aiResponse = "Yes, knee surgery is covered under your policy! You can claim up to ₹50,000 for the procedure. Based on your room rent limit of ₹3,000/day, you may need to pay approximately ₹5,000 extra if you choose a higher room category."
      } else if (messageText.toLowerCase().includes("cashless")) {
        aiResponse = "For cashless claims, visit any of our 8,000+ network hospitals. Show your health card at admission, and we'll handle the paperwork directly with the hospital. No upfront payment needed for covered treatments!"
      } else if (messageText.toLowerCase().includes("room") || messageText.toLowerCase().includes("rent")) {
        aiResponse = "Your room rent limit is ₹3,000/day. If you choose a room costing ₹4,000/day, you'll pay the difference of ₹1,000/day. This applies to all medical expenses proportionally."
      } else if (messageText.toLowerCase().includes("pre-existing") || messageText.toLowerCase().includes("existing")) {
        aiResponse = "Pre-existing conditions are covered after a 2-year waiting period from your policy start date. Since your policy started in January 2023, conditions like diabetes or hypertension will be covered from January 2025."
      } else {
        aiResponse = "I understand you're asking about your coverage. Could you tell me more specifically what you'd like to know? I can help with claims, coverage limits, network hospitals, or policy details."
      }

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "ai",
        content: aiResponse,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, aiMessage])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="px-5 py-4 border-b border-border/50 flex items-center gap-4">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-card flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </motion.button>
        <div className="flex items-center gap-3 flex-1">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-foreground font-semibold">INTACT AI</h1>
            <p className="text-xs text-muted-foreground">Always here to help</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                  message.type === "user"
                    ? "bg-primary text-white rounded-br-md"
                    : "bg-card border border-border/50 text-foreground rounded-bl-md"
                }`}
              >
                <p className="text-sm leading-relaxed">{message.content}</p>
                <p className={`text-[10px] mt-1 ${message.type === "user" ? "text-white/60" : "text-muted-foreground"}`}>
                  {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex justify-start"
            >
              <div className="bg-card border border-border/50 rounded-2xl rounded-bl-md px-4 py-3">
                <div className="flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      className="w-2 h-2 bg-muted-foreground rounded-full"
                      animate={{ y: [0, -5, 0] }}
                      transition={{
                        duration: 0.6,
                        repeat: Infinity,
                        delay: i * 0.15,
                      }}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompts */}
      {messages.length <= 2 && (
        <div className="px-5 pb-3">
          <p className="text-xs text-muted-foreground mb-2">Suggested questions</p>
          <div className="flex flex-wrap gap-2">
            {suggestedPrompts.map((prompt) => (
              <motion.button
                key={prompt}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleSend(prompt.replace("&apos;", "'"))}
                className="px-3 py-2 rounded-full bg-card border border-border/50 text-xs text-foreground hover:border-primary/50 transition-colors flex items-center gap-1"
              >
                {prompt.replace("&apos;", "'")}
                <ChevronRight className="w-3 h-3 text-muted-foreground" />
              </motion.button>
            ))}
          </div>
        </div>
      )}

      {/* Input Area */}
      <div className="px-5 py-4 border-t border-border/50">
        <div className="flex items-center gap-2">
          <motion.button
            whileTap={{ scale: 0.9 }}
            className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center"
          >
            <Paperclip className="w-5 h-5 text-muted-foreground" />
          </motion.button>
          
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Ask anything about your policy..."
              className="w-full bg-card border border-border/50 rounded-full px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 transition-colors"
            />
          </div>
          
          {inputValue ? (
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => handleSend()}
              className="w-10 h-10 rounded-full bg-primary flex items-center justify-center"
            >
              <Send className="w-5 h-5 text-white" />
            </motion.button>
          ) : (
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="w-10 h-10 rounded-full bg-card border border-border/50 flex items-center justify-center"
            >
              <Mic className="w-5 h-5 text-muted-foreground" />
            </motion.button>
          )}
        </div>
      </div>
    </div>
  )
}
