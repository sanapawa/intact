"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { 
  ArrowLeft, 
  Building2, 
  Upload, 
  FileCheck, 
  Send,
  Check,
  ChevronRight,
  Sparkles,
  MapPin,
  Search
} from "lucide-react"

const steps = [
  { id: 1, title: "Select Hospital", icon: Building2 },
  { id: 2, title: "Upload Documents", icon: Upload },
  { id: 3, title: "Review Details", icon: FileCheck },
  { id: 4, title: "Submit", icon: Send },
]

const hospitals = [
  { name: "Apollo Hospital", location: "Jubilee Hills", distance: "2.3 km", network: true },
  { name: "Yashoda Hospital", location: "Somajiguda", distance: "4.1 km", network: true },
  { name: "KIMS Hospital", location: "Secunderabad", distance: "5.8 km", network: true },
  { name: "Care Hospital", location: "Banjara Hills", distance: "3.2 km", network: true },
]

const documents = [
  { name: "Hospital Bills", required: true, uploaded: false },
  { name: "Discharge Summary", required: true, uploaded: false },
  { name: "Doctor Prescription", required: true, uploaded: false },
  { name: "Lab Reports", required: false, uploaded: false },
]

interface ClaimFlowScreenProps {
  onBack: () => void
  onNavigate: (screen: string) => void
}

export function ClaimFlowScreen({ onBack, onNavigate }: ClaimFlowScreenProps) {
  const [currentStep, setCurrentStep] = useState(1)
  const [selectedHospital, setSelectedHospital] = useState<string | null>(null)
  const [uploadedDocs, setUploadedDocs] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState("")

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1)
    } else {
      // Submit claim
      onNavigate("claim-status")
    }
  }

  const handleDocUpload = (docName: string) => {
    if (uploadedDocs.includes(docName)) {
      setUploadedDocs(uploadedDocs.filter((d) => d !== docName))
    } else {
      setUploadedDocs([...uploadedDocs, docName])
    }
  }

  const canProceed = () => {
    if (currentStep === 1) return selectedHospital !== null
    if (currentStep === 2) return uploadedDocs.length >= 3
    return true
  }

  const filteredHospitals = hospitals.filter((h) =>
    h.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    h.location.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="px-5 py-4 border-b border-border/50">
        <div className="flex items-center gap-4 mb-4">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-card flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </motion.button>
          <div>
            <h1 className="text-lg font-semibold text-foreground">File a Claim</h1>
            <p className="text-xs text-muted-foreground">Step {currentStep} of 4</p>
          </div>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-between">
          {steps.map((step, index) => (
            <div key={step.id} className="flex items-center">
              <motion.div
                initial={{ scale: 0.8 }}
                animate={{ 
                  scale: currentStep >= step.id ? 1 : 0.8,
                  backgroundColor: currentStep >= step.id ? "#1D4ED8" : "#262626"
                }}
                className="w-8 h-8 rounded-full flex items-center justify-center"
              >
                {currentStep > step.id ? (
                  <Check className="w-4 h-4 text-white" />
                ) : (
                  <step.icon className={`w-4 h-4 ${currentStep >= step.id ? "text-white" : "text-muted-foreground"}`} />
                )}
              </motion.div>
              {index < steps.length - 1 && (
                <div className="w-8 h-0.5 bg-muted mx-1">
                  <motion.div
                    className="h-full bg-primary"
                    initial={{ width: 0 }}
                    animate={{ width: currentStep > step.id ? "100%" : "0%" }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-5 py-6">
        <AnimatePresence mode="wait">
          {/* Step 1: Select Hospital */}
          {currentStep === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="flex items-start gap-3 p-4 rounded-2xl bg-primary/10 border border-primary/20">
                <Sparkles className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <p className="text-sm text-foreground">We&apos;ve found network hospitals near you for cashless claims</p>
              </div>

              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search hospitals..."
                  className="w-full bg-card border border-border/50 rounded-2xl pl-12 pr-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50"
                />
              </div>

              <div className="space-y-3">
                {filteredHospitals.map((hospital) => (
                  <motion.button
                    key={hospital.name}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedHospital(hospital.name)}
                    className={`w-full p-4 rounded-2xl border transition-all text-left ${
                      selectedHospital === hospital.name
                        ? "bg-primary/10 border-primary"
                        : "bg-card border-border/50"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-foreground">{hospital.name}</h3>
                          {hospital.network && (
                            <span className="px-2 py-0.5 bg-[#22C55E]/20 text-[#22C55E] text-[10px] rounded-full font-medium">
                              Network
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                          <MapPin className="w-3 h-3" />
                          <span>{hospital.location}</span>
                          <span>•</span>
                          <span>{hospital.distance}</span>
                        </div>
                      </div>
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        selectedHospital === hospital.name ? "border-primary bg-primary" : "border-muted-foreground"
                      }`}>
                        {selectedHospital === hospital.name && (
                          <Check className="w-3 h-3 text-white" />
                        )}
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Step 2: Upload Documents */}
          {currentStep === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="flex items-start gap-3 p-4 rounded-2xl bg-primary/10 border border-primary/20">
                <Sparkles className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <p className="text-sm text-foreground">Tap to upload or use the document scanner for auto-detection</p>
              </div>

              <div className="space-y-3">
                {documents.map((doc) => (
                  <motion.button
                    key={doc.name}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleDocUpload(doc.name)}
                    className={`w-full p-4 rounded-2xl border transition-all ${
                      uploadedDocs.includes(doc.name)
                        ? "bg-[#22C55E]/10 border-[#22C55E]"
                        : "bg-card border-border/50 border-dashed"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                          uploadedDocs.includes(doc.name) ? "bg-[#22C55E]" : "bg-muted"
                        }`}>
                          {uploadedDocs.includes(doc.name) ? (
                            <Check className="w-5 h-5 text-white" />
                          ) : (
                            <Upload className="w-5 h-5 text-muted-foreground" />
                          )}
                        </div>
                        <div className="text-left">
                          <p className="font-medium text-foreground">{doc.name}</p>
                          <p className="text-xs text-muted-foreground">
                            {doc.required ? "Required" : "Optional"}
                          </p>
                        </div>
                      </div>
                      {uploadedDocs.includes(doc.name) && (
                        <span className="text-xs text-[#22C55E] font-medium">Uploaded</span>
                      )}
                    </div>
                  </motion.button>
                ))}
              </div>

              <motion.button
                whileTap={{ scale: 0.98 }}
                onClick={() => onNavigate("document-scanner")}
                className="w-full p-4 rounded-2xl bg-gradient-to-r from-[#1D4ED8] to-[#1E40AF] text-white font-medium flex items-center justify-center gap-2"
              >
                <span>Open Document Scanner</span>
                <ChevronRight className="w-4 h-4" />
              </motion.button>
            </motion.div>
          )}

          {/* Step 3: Review Details */}
          {currentStep === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <div className="flex items-start gap-3 p-4 rounded-2xl bg-primary/10 border border-primary/20">
                <Sparkles className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <p className="text-sm text-foreground">We&apos;ve pre-filled most details for you. Please review and confirm.</p>
              </div>

              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-card border border-border/50">
                  <h3 className="text-sm text-muted-foreground mb-3">Hospital Details</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Hospital</span>
                      <span className="text-sm font-medium text-foreground">{selectedHospital}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Claim Type</span>
                      <span className="text-sm font-medium text-foreground">Cashless</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-card border border-border/50">
                  <h3 className="text-sm text-muted-foreground mb-3">Patient Details</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Name</span>
                      <span className="text-sm font-medium text-foreground">Sana Sharma</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Policy No.</span>
                      <span className="text-sm font-medium text-foreground">INT-2024-001234</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Coverage</span>
                      <span className="text-sm font-medium text-foreground">₹5,00,000</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-card border border-border/50">
                  <h3 className="text-sm text-muted-foreground mb-3">Documents Uploaded</h3>
                  <div className="flex flex-wrap gap-2">
                    {uploadedDocs.map((doc) => (
                      <span key={doc} className="px-3 py-1 bg-[#22C55E]/20 text-[#22C55E] text-xs rounded-full font-medium">
                        {doc}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 4: Submit */}
          {currentStep === 4 && (
            <motion.div
              key="step4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex flex-col items-center justify-center h-full text-center space-y-6 py-8"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", delay: 0.2 }}
                className="w-24 h-24 rounded-full bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] flex items-center justify-center"
              >
                <Send className="w-10 h-10 text-white" />
              </motion.div>
              
              <div>
                <h2 className="text-xl font-bold text-foreground mb-2">Ready to Submit!</h2>
                <p className="text-muted-foreground text-sm max-w-[250px]">
                  Your claim will be sent to the insurer for processing. You&apos;ll receive updates in real-time.
                </p>
              </div>

              <div className="w-full p-4 rounded-2xl bg-card border border-border/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-primary" />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-medium text-foreground">Estimated Processing</p>
                    <p className="text-xs text-muted-foreground">2-3 business days</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <div className="px-5 py-4 border-t border-border/50">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={handleNext}
          disabled={!canProceed()}
          className={`w-full py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 transition-all ${
            canProceed()
              ? "bg-gradient-to-r from-[#1D4ED8] to-[#1E40AF] text-white"
              : "bg-muted text-muted-foreground"
          }`}
        >
          {currentStep === 4 ? "Submit Claim" : "Continue"}
          <ChevronRight className="w-5 h-5" />
        </motion.button>
      </div>
    </div>
  )
}
