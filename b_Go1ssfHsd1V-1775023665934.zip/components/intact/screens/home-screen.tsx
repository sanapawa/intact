"use client"

import { motion } from "framer-motion"
import { 
  FileText, 
  Upload, 
  Search, 
  MessageCircle,
  ChevronRight,
  Shield,
  Sparkles
} from "lucide-react"
import Image from "next/image"

const quickActions = [
  { icon: FileText, label: "File Claim", color: "from-[#1D4ED8] to-[#1E40AF]" },
  { icon: Upload, label: "Upload Docs", color: "from-[#1D4ED8]/80 to-[#1E40AF]/80" },
  { icon: Search, label: "Track Claim", color: "from-[#1D4ED8]/60 to-[#1E40AF]/60" },
  { icon: MessageCircle, label: "Ask AI", color: "from-[#1D4ED8]/40 to-[#1E40AF]/40" },
]

const claimSteps = [
  { label: "Submitted", status: "complete" },
  { label: "Under Review", status: "current" },
  { label: "Approved", status: "pending" },
  { label: "Paid", status: "pending" },
]

interface HomeScreenProps {
  onNavigate: (screen: string) => void
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  return (
    <div className="px-5 py-6 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-3"
      >
        <div className="flex items-center gap-2">
          <Image src="/logo.png" alt="INTACT" width={32} height={32} className="rounded-lg" />
          <span className="text-sm font-semibold text-foreground">INTACT</span>
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">Hi Sana</h1>
          <p className="text-muted-foreground text-sm mt-0.5">Your health cover, simplified</p>
        </div>
      </motion.div>

      {/* Hero Policy Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] p-6"
        onClick={() => onNavigate("policy")}
      >
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
        
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-white/90" />
            <span className="text-white/90 text-sm font-medium">Family Floater Plan</span>
          </div>
          
          <div className="mb-4">
            <p className="text-white/70 text-xs uppercase tracking-wider mb-1">Total Coverage</p>
            <p className="text-4xl font-bold text-white">₹5,00,000</p>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-[#22C55E] rounded-full animate-pulse" />
              <span className="text-white/90 text-sm">Active</span>
            </div>
            
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={(e) => {
                e.stopPropagation()
                onNavigate("claim-flow")
              }}
              className="bg-white text-[#1D4ED8] px-5 py-2.5 rounded-full text-sm font-semibold flex items-center gap-1.5 shadow-lg"
            >
              Start a Claim
              <ChevronRight className="w-4 h-4" />
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">Quick Actions</h2>
        <div className="grid grid-cols-4 gap-3">
          {quickActions.map((action, index) => (
            <motion.button
              key={action.label}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 + index * 0.05 }}
              onClick={() => {
                if (action.label === "File Claim") onNavigate("claim-flow")
                else if (action.label === "Upload Docs") onNavigate("document-scanner")
                else if (action.label === "Track Claim") onNavigate("claim-status")
                else if (action.label === "Ask AI") onNavigate("ai-chat")
              }}
              className="flex flex-col items-center gap-2 p-3 rounded-2xl bg-card border border-border/50 hover:border-primary/50 transition-colors"
            >
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${action.color} flex items-center justify-center`}>
                <action.icon className="w-5 h-5 text-white" />
              </div>
              <span className="text-xs text-foreground font-medium text-center leading-tight">{action.label}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* AI Assistant Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        onClick={() => onNavigate("ai-chat")}
        className="p-5 rounded-2xl bg-card border border-border/50 cursor-pointer hover:border-primary/30 transition-colors"
      >
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#1D4ED8] to-[#1E40AF] flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-foreground font-medium mb-1">Ask INTACT AI</p>
            <div className="bg-muted/50 rounded-xl p-3 mb-3">
              <p className="text-muted-foreground text-sm italic">&quot;Am I covered for knee surgery?&quot;</p>
            </div>
            <div className="flex items-center gap-2 text-primary text-sm font-medium">
              <MessageCircle className="w-4 h-4" />
              <span>Chat with AI</span>
              <ChevronRight className="w-4 h-4 ml-auto" />
            </div>
          </div>
        </div>
      </motion.div>

      {/* Claim Status Tracker */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        onClick={() => onNavigate("claim-status")}
        className="p-5 rounded-2xl bg-card border border-border/50 cursor-pointer"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-foreground font-semibold">Active Claim</h3>
          <span className="text-xs text-muted-foreground">CLM-2024-001</span>
        </div>
        
        {/* Progress Steps */}
        <div className="relative">
          <div className="flex justify-between items-center mb-2">
            {claimSteps.map((step, index) => (
              <div key={step.label} className="flex flex-col items-center relative z-10">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.3, delay: 0.6 + index * 0.1 }}
                  className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    step.status === "complete" 
                      ? "bg-[#22C55E]" 
                      : step.status === "current"
                        ? "bg-primary animate-pulse"
                        : "bg-muted"
                  }`}
                >
                  {step.status === "complete" && (
                    <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                  {step.status === "current" && (
                    <div className="w-2 h-2 bg-white rounded-full" />
                  )}
                </motion.div>
              </div>
            ))}
          </div>
          
          {/* Progress Line */}
          <div className="absolute top-3 left-3 right-3 h-0.5 bg-muted -z-0">
            <motion.div 
              className="h-full bg-[#22C55E]"
              initial={{ width: "0%" }}
              animate={{ width: "35%" }}
              transition={{ duration: 0.8, delay: 0.7 }}
            />
          </div>
          
          {/* Labels */}
          <div className="flex justify-between mt-2">
            {claimSteps.map((step) => (
              <span 
                key={step.label} 
                className={`text-[10px] text-center w-14 ${
                  step.status === "pending" ? "text-muted-foreground" : "text-foreground"
                }`}
              >
                {step.label}
              </span>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  )
}
