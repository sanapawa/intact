"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Image from "next/image"

interface SplashScreenProps {
  onComplete: () => void
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [phase, setPhase] = useState<"logo" | "tagline" | "exit">("logo")

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("tagline"), 1000)
    const t2 = setTimeout(() => setPhase("exit"), 2600)
    const t3 = setTimeout(() => onComplete(), 3200)
    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
      clearTimeout(t3)
    }
  }, [onComplete])

  return (
    <AnimatePresence>
      {phase !== "exit" ? (
        <motion.div
          key="splash"
          className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-white rounded-[44px] overflow-hidden"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
        >
          {/* Radial glow behind logo */}
          <motion.div
            className="absolute inset-0 pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: phase === "tagline" ? 1 : 0 }}
            transition={{ duration: 1 }}
            style={{
              background:
                "radial-gradient(ellipse 60% 40% at 50% 50%, rgba(29,78,216,0.18) 0%, transparent 70%)",
            }}
          />

          {/* Logo mark */}
          <motion.div
            className="flex flex-col items-center gap-6"
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
          >
            <motion.div
              animate={phase === "tagline" ? { y: -8 } : { y: 0 }}
              transition={{ duration: 0.6, ease: "easeInOut" }}
            >
              <Image
                src="/logo.png"
                alt="INTACT"
                width={96}
                height={96}
                className="rounded-[28px]"
                priority
              />
            </motion.div>

            {/* Wordmark */}
            <motion.div className="flex flex-col items-center gap-1">
              <motion.span
                className="text-[#0B0B0B] text-3xl font-bold tracking-[0.12em]"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.5 }}
              >
                INTACT
              </motion.span>

              {/* Tagline fades in on second phase */}
              <AnimatePresence>
                {phase === "tagline" && (
                  <motion.span
                    key="tagline"
                    className="text-[#6B7280] text-sm font-normal tracking-wide text-center"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    Health, kept INTACT.
                  </motion.span>
                )}
              </AnimatePresence>
            </motion.div>
          </motion.div>

          {/* Loading bar at bottom */}
          <motion.div
            className="absolute bottom-10 left-10 right-10 h-[2px] rounded-full bg-[#E5E7EB] overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: phase === "tagline" ? 1 : 0 }}
            transition={{ duration: 0.4 }}
          >
            <motion.div
              className="h-full rounded-full bg-[#1D4ED8]"
              initial={{ width: "0%" }}
              animate={{ width: phase === "tagline" ? "100%" : "0%" }}
              transition={{ duration: 1.4, ease: "easeInOut" }}
            />
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  )
}
