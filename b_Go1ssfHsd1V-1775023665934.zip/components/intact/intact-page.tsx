"use client"

import { IntactApp } from "@/components/intact/intact-app"
import Image from "next/image"

export function IntactPage() {
  return (
    <main className="min-h-screen bg-white flex items-center justify-center p-4 md:p-8">
      {/* Background gradient */}
      <div className="fixed inset-0 bg-gradient-to-br from-[#1D4ED8]/[0.03] via-transparent to-[#1D4ED8]/[0.03] pointer-events-none" />

      {/* App Header */}
      <div className="fixed top-0 left-0 right-0 flex items-center justify-between px-6 py-4 z-50 border-b border-[#E5E7EB] bg-white/80 backdrop-blur-sm">
        <div className="flex items-center gap-3">
          <Image src="/logo.png" alt="INTACT" width={40} height={40} className="rounded-lg" priority />
          <div>
            <div className="font-bold text-lg tracking-tight text-[#0B0B0B]">INTACT</div>
            <div className="text-xs text-[#6B7280]">Health Insurance AI</div>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-6 text-sm text-[#6B7280]">
          <span>Interactive Demo</span>
          <span className="text-[#1D4ED8] font-medium">Try it now</span>
        </div>
      </div>

      {/* Phone Container */}
      <div className="relative z-10 mt-16">
        <IntactApp />
      </div>

      {/* Feature highlights - Desktop only */}
      <div className="hidden lg:block fixed left-8 top-1/2 -translate-y-1/2 max-w-[200px] space-y-4">
        <FeatureCard title="AI-Powered" description="Get instant answers about your coverage" />
        <FeatureCard title="Smart Scanner" description="Auto-detect and validate documents" />
        <FeatureCard title="Real-time Tracking" description="Monitor your claim status live" />
      </div>

      <div className="hidden lg:block fixed right-8 top-1/2 -translate-y-1/2 max-w-[200px] space-y-4">
        <FeatureCard title="Policy Explainer" description="Understand your coverage in plain language" />
        <FeatureCard title="Cashless Claims" description="File claims at 8,000+ hospitals" />
        <FeatureCard title="Always There" description="A calm companion when you need it" />
      </div>
    </main>
  )
}

function FeatureCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="p-4 rounded-2xl bg-white border border-[#E5E7EB] shadow-sm hover:shadow-md transition-shadow">
      <h3 className="text-[#0B0B0B] font-semibold text-sm mb-1">{title}</h3>
      <p className="text-[#6B7280] text-xs">{description}</p>
    </div>
  )
}
