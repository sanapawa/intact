"use client"

import { ReactNode } from "react"

interface PhoneFrameProps {
  children: ReactNode
  showStatusBar?: boolean
}

export function PhoneFrame({ children, showStatusBar = true }: PhoneFrameProps) {
  return (
    <div className="relative w-[375px] h-[812px] bg-background rounded-[44px] overflow-hidden shadow-2xl border-[8px] border-[#1A1A1A]">
      {/* Notch */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[150px] h-[34px] bg-[#0B0B0B] rounded-b-[20px] z-50" />
      
      {/* Status Bar */}
      {showStatusBar && (
        <div className="absolute top-0 left-0 right-0 h-[44px] flex items-center justify-between px-6 z-40">
          <span className="text-xs font-semibold text-foreground">9:41</span>
          <div className="flex items-center gap-1">
            <svg className="w-4 h-4 text-foreground" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 3c-4.97 0-9 4.03-9 9s4.03 9 9 9 9-4.03 9-9-4.03-9-9-9zm0 16c-3.86 0-7-3.14-7-7s3.14-7 7-7 7 3.14 7 7-3.14 7-7 7z"/>
            </svg>
            <svg className="w-4 h-4 text-foreground" fill="currentColor" viewBox="0 0 24 24">
              <path d="M1 9l2 2c4.97-4.97 13.03-4.97 18 0l2-2C16.93 2.93 7.08 2.93 1 9zm8 8l3 3 3-3c-1.65-1.66-4.34-1.66-6 0zm-4-4l2 2c2.76-2.76 7.24-2.76 10 0l2-2C15.14 9.14 8.87 9.14 5 13z"/>
            </svg>
            <div className="w-6 h-3 bg-foreground rounded-sm relative">
              <div className="absolute right-0 top-1/2 -translate-y-1/2 -right-[3px] w-1 h-2 bg-foreground rounded-r-sm" />
            </div>
          </div>
        </div>
      )}
      
      {/* Content */}
      <div className="h-full overflow-y-auto pt-[44px] pb-[34px]">
        {children}
      </div>
      
      {/* Home Indicator */}
      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-[134px] h-[5px] bg-foreground/30 rounded-full" />
    </div>
  )
}
